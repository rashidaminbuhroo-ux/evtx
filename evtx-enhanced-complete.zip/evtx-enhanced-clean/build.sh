#!/bin/bash

# EVTX Enhanced Viewer - Build Script
# This script handles building the Rust WASM module and web application

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WASM_DIR="$PROJECT_ROOT/evtx-wasm"
VIEWER_DIR="$WASM_DIR/evtx-viewer"
BUILD_TARGET="${1:-dev}"  # dev or prod

echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}EVTX Enhanced Viewer - Build Script${NC}"
echo -e "${BLUE}================================================${NC}"
echo -e "Project Root: ${GREEN}$PROJECT_ROOT${NC}"
echo -e "Build Target: ${GREEN}$BUILD_TARGET${NC}"
echo ""

# Function to print status
print_status() {
    echo -e "${YELLOW}▶${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Check prerequisites
print_status "Checking prerequisites..."

if ! command -v rustc &> /dev/null; then
    print_error "Rust not found. Install from https://rustup.rs"
    exit 1
fi
print_success "Rust found ($(rustc --version))"

if ! command -v node &> /dev/null; then
    print_error "Node.js not found. Install from https://nodejs.org"
    exit 1
fi
print_success "Node.js found ($(node --version))"

if ! command -v npm &> /dev/null; then
    print_error "npm not found"
    exit 1
fi
print_success "npm found ($(npm --version))"

if ! command -v wasm-pack &> /dev/null; then
    print_status "wasm-pack not found, installing..."
    curl https://rustwasm.org/wasm-pack/installer/init.sh -sSf | sh
    print_success "wasm-pack installed"
else
    print_success "wasm-pack found ($(wasm-pack --version))"
fi

echo ""
print_status "Building WASM module..."

cd "$WASM_DIR"

if [ "$BUILD_TARGET" = "prod" ]; then
    print_status "Building with optimizations..."
    wasm-pack build --target bundler --release
else
    print_status "Building in development mode..."
    wasm-pack build --target bundler
fi

print_success "WASM module built successfully"

echo ""
print_status "Installing web dependencies..."

cd "$VIEWER_DIR"

if [ ! -d "node_modules" ]; then
    npm install
    print_success "Dependencies installed"
else
    print_success "Dependencies already installed"
fi

echo ""
print_status "Building web application..."

if [ "$BUILD_TARGET" = "prod" ]; then
    print_status "Production build..."
    npm run build
    print_success "Production build complete"
    echo -e "${GREEN}Output: $VIEWER_DIR/dist${NC}"
else
    print_status "Development build..."
    npm run build:dev 2>/dev/null || npm run build
    print_success "Development build complete"
fi

echo ""
print_status "Building CLI tool (optional)..."

cd "$PROJECT_ROOT"

if cargo build --release 2>/dev/null; then
    print_success "CLI tool built: target/release/evtx_dump"
else
    print_status "Skipping CLI tool (optional)"
fi

echo ""
echo -e "${BLUE}================================================${NC}"
echo -e "${GREEN}✓ Build complete!${NC}"
echo -e "${BLUE}================================================${NC}"

echo ""
echo -e "${YELLOW}Next steps:${NC}"

if [ "$BUILD_TARGET" = "prod" ]; then
    echo "1. Deploy the dist folder:"
    echo "   cd $VIEWER_DIR"
    echo "   serve -s dist -l 3000"
    echo ""
    echo "2. Or use Docker:"
    echo "   docker-compose up --build"
else
    echo "1. Start development server:"
    echo "   cd $VIEWER_DIR"
    echo "   npm run dev"
    echo ""
    echo "2. Browser will open at http://localhost:5173"
fi

echo ""
echo -e "${YELLOW}Docker deployment:${NC}"
echo "  cd $PROJECT_ROOT"
echo "  docker-compose up --build"
echo "  # Access at http://localhost:3000"

echo ""
echo -e "${GREEN}✓ Ready to go!${NC}"
