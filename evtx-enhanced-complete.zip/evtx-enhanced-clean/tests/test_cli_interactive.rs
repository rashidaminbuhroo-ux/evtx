/// The interactive tests are in a separate file,
/// since they use `rexpect`, which internally uses quirky fork semantics to open a pty.
/// They will fail if tried to be executed concurrently any other CLI test.
mod fixtures;

#[cfg(target_os = "windows")]
mod tests {}

#[cfg(not(target_os = "windows"))]
mod tests {
    use super::fixtures::*;

    use rexpect::spawn;
    use std::fs::File;
    use std::io::{Read, Write};
    use std::time::{Duration, Instant};
    use tempfile::tempdir;

    fn wait_for_file_len_at_least(path: &std::path::Path, min_len: usize, timeout: Duration) -> usize {
        let start = Instant::now();
        loop {
            if let Ok(meta) = std::fs::metadata(path) {
                let len = meta.len() as usize;
                if len >= min_len {
                    return len;
                }
            }
            if start.elapsed() >= timeout {
                let len = std::fs::metadata(path).map(|m| m.len() as usize).unwrap_or(0);
                return len;
            }
            std::thread::sleep(Duration::from_millis(25));
        }
    }

    // It should behave the same on windows, but interactive testing relies on unix pty internals.
    #[test]
    #[cfg(not(target_os = "windows"))]
    fn test_it_confirms_before_overwriting_a_file() {
        let _guard = CLI_TEST_LOCK.lock().unwrap();
        let d = tempdir().unwrap();
        let f = d.as_ref().join("test.out");

        let mut file = File::create(&f).unwrap();
        file.write_all(b"I'm a file!").unwrap();

        let sample = regular_sample();

        let cmd_string = format!(
            "{bin} -f {output_file} {sample}",
            bin = assert_cmd::cargo_bin!("evtx_dump").display(),
            output_file = f.to_string_lossy(),
            sample = sample.to_str().unwrap()
        );

        let mut p = spawn(&cmd_string, Some(1000)).unwrap();
        p.exp_regex(r#"Are you sure you want to override.*"#)
            .unwrap();
        p.send_line("y").unwrap();
        p.flush().unwrap();

        // Wait for the file to be overwritten. Under load, parsing can take longer than 100ms.
        let len = wait_for_file_len_at_least(&f, 100, Duration::from_secs(10));
        assert!(len >= 100, "Expected output to be printed to file");
    }

    #[test]
    #[cfg(not(target_os = "windows"))]
    fn test_it_confirms_before_overwriting_a_file_and_quits() {
        let _guard = CLI_TEST_LOCK.lock().unwrap();
        let d = tempdir().unwrap();
        let f = d.as_ref().join("test.out");

        let mut file = File::create(&f).unwrap();
        file.write_all(b"I'm a file!").unwrap();

        let sample = regular_sample();

        let cmd_string = format!(
            "{bin} -f {output_file} {sample}",
            bin = assert_cmd::cargo_bin!("evtx_dump").display(),
            output_file = f.to_string_lossy(),
            sample = sample.to_str().unwrap()
        );

        let mut p = spawn(&cmd_string, Some(10000)).unwrap();
        p.exp_regex(r#"Are you sure you want to override.*"#)
            .unwrap();
        p.send_line("n").unwrap();
        p.flush().unwrap();
        std::thread::sleep(Duration::from_millis(100));

        let mut expected = vec![];

        File::open(&f).unwrap().read_to_end(&mut expected).unwrap();
        assert_eq!(
            expected.as_slice(),
            b"I'm a file!",
            "Expected output file to remain unchanged"
        );
    }
}
